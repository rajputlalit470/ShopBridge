import { Component, OnInit } from '@angular/core';
import { TableService } from '../table.service';
import {initialData} from '../shared/data';
import { IProduct } from '../shared/product.interface';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})
export class AddProductComponent implements OnInit {
  productData = initialData;
  constructor(private tableService: TableService) { }

  ngOnInit(): void {
  }

  getFormData(data){
    console.log(data);
    this.tableService.saveData(data);
    this.tableService.isProductDeleted.next(true);
  }
}
