import { Component, OnInit } from '@angular/core';
import { IProduct } from '../shared/product.interface';
import { TableService } from '../table.service';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html'
})

export class HeaderComponent implements OnInit {
    productsCount:number = 0;
    products:IProduct[] = [];
    constructor(private tableService:TableService) { }

    ngOnInit() {
        this.tableService.productsAddedToCart.subscribe((data)=>{
            if(data){
                this.products = data;
                this.productsCount = this.products.length;
                console.log(this.productsCount);
            }
        });
     }
    showModal(){
    }
    removeFromCart(id:number){
        this.products.forEach((product,index)=>{
            if(product.id===id){
                this.products.splice(index,1);
            }
        });
        this.productsCount = this.products.length;
        this.tableService.productsAddedToCart.next(this.products);
    }
}