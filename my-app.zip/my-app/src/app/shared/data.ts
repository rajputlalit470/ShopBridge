export const initialData =  {
    id: 1,
    productName: "",
    productCode: "",
    description: "",
    releaseDate: "",
    price: 0
  };
