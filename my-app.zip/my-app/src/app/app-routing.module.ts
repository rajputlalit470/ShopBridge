import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { DetailProductComponent } from './detail-product/detail-product.component';
import { ModifyProductComponent } from './modify-product/modify-product.component';
import { SecondPageComponent } from './second-page/second-page.component';


const routes: Routes = [
  {path:'',redirectTo:'/products',pathMatch:'full'},
  {path:'products',component:SecondPageComponent},
  {
    path: 'products/:id',
    component: DetailProductComponent
  },
  {
    path: 'products/modify/:id',
    component: ModifyProductComponent
  },
  {
    path: 'addProduct',
    component: AddProductComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
