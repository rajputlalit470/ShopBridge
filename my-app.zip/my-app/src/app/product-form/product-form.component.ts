import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { IProduct } from '../shared/product.interface';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {initialData} from '../shared/data';
@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.scss']
})
export class ProductFormComponent implements OnInit {
  productData:IProduct;
  productForm: FormGroup;
  @Input()
  set data(value: IProduct) {
    console.log(value);
    this.productData = value;
}
  @Output() formData: EventEmitter<IProduct> = new EventEmitter<IProduct>();
  constructor( private router: Router) { }
  ngOnInit(): void {
    this.productForm = new FormGroup({
      'id': new FormControl(''),
      'productName': new FormControl('',Validators.required),
      'productCode': new FormControl('',Validators.required),
      'description': new FormControl('',Validators.required),
      'releaseDate': new FormControl('',[Validators.required]),
      'price': new FormControl('',Validators.required),
      'isProductAddedToCart': new FormControl('',Validators.required)
    });
    console.log(this.productData);
    this.productForm.setValue(this.productData?this.productData:initialData);
  }
  onBack(): void {
    this.router.navigate(['/products']);
  }

  onSubmit(){
    if(this.productForm.valid){
      this.formData.emit(this.productForm.value);
    }
  }
}
