import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import {TableService} from '../table.service';
import { IProduct } from '../shared/product.interface';
@Component({
  selector: 'app-second-page',
  templateUrl: './second-page.component.html',
  styleUrls: ['./second-page.component.scss']
})
export class SecondPageComponent implements OnInit,OnDestroy {
  errorMessage = '';
  listFilter = '';
  pageTitle = 'Product List';
  products: IProduct[] = [];
  productsAddedToCart: IProduct[] = [];
  filteredProducts: IProduct[] = [];
  isProductRemoved:boolean = false;
  productAddedToCartById:number[] = [];
  constructor(private router: Router,private tableService:TableService) { }

  ngOnInit(): void {
    this.getProductsData();
    this.getProductsAddedToCart();
  }

  getProductsAddedToCart(){
    this.tableService.productsAddedToCart.subscribe((data)=>{
      if(data){
        this.productsAddedToCart = data;
        data.forEach((product)=>{
          this.productAddedToCartById.push(product.id);
        });
        if(data.length==0){
          this.productAddedToCartById = [];
        }
        console.log(this.productAddedToCartById);
        this.products.forEach((product)=>{
          if(this.productAddedToCartById.indexOf(product.id)===-1){
            product.isProductAddedToCart = false;
          }
        });
        this.productAddedToCartById = [];
      }
    });
  }

  getProductsData(){
    this.tableService.getData().subscribe({
      next: products => {
        this.tableService.setProductData(products);
        this.products = products;
        this.filteredProducts = this.products;
        this.tableService.isProductDeleted.next(true);
        console.log(this.products);
      },
      error: err => this.errorMessage = err
    });
  }
  ngOnDestroy(){
    // this.tableService.isProductDeleted.unsubscribe();
  }
  removeItem(id){
    console.log(id);
    this.tableService.removeProductById(id);
    this.tableService.isProductDeleted.subscribe(data=>{
      if(data){
        this.getProductsData();
      }
    });
  }

  modifyItem(id:number){
    this.router.navigate([`products/modify/${id}`]);
  }

  getData(){
   
  }

  AddProduct(){
    this.router.navigate(['addProduct']);
  }
  addToCart(id:number){
    this.products.forEach((productObject)=>{
      if(productObject.id === id){
        // this.productAddedToCartById.push(id);
        productObject.isProductAddedToCart = true;
        this.productsAddedToCart.push(productObject);
      }
    });
    this.tableService.productsAddedToCart.next(this.productsAddedToCart);
  }

  isDisable(id:number){
    this.productsAddedToCart.forEach((productObject)=>{
      if(productObject.id === id){
        return true;
      }
    });
  }
}
