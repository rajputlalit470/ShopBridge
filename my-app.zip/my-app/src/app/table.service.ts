import { Injectable, OnDestroy } from '@angular/core';
import {HttpClient, HttpErrorResponse, HttpHeaders,} from '@angular/common/http';
import { IProduct } from './shared/product.interface';
import { catchError, tap, map } from 'rxjs/operators';
import { Observable, throwError,BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class TableService implements OnDestroy {
  ProductData = new BehaviorSubject<IProduct[]>(null);
  isProductDeleted = new BehaviorSubject<boolean>(false);
  productsAddedToCart = new BehaviorSubject<IProduct[]>(null);
  private productUrl = 'http://localhost:3000/products';
  status: string;
  constructor(private httpClient: HttpClient) { }
  getData(){
    return this.httpClient.get<IProduct[]>(this.productUrl)
    .pipe(
      tap(data => {
        console.log('All: ' + JSON.stringify(data));
        this.ProductData.next(data);
      }),
      catchError(this.handleError)
    );
  }

  getProductData(){
    return this.ProductData.asObservable();
  }

  setProductData(data:IProduct[]){
    this.ProductData.next(data);
  }

  getProductById(id:number){
    return this.httpClient.get<IProduct>(`${this.productUrl}/${id}`)
    .pipe(
      tap(data => console.log('All: ' + JSON.stringify(data))),
      catchError(this.handleError)
    );
  }

  saveProductById(data:IProduct){
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.httpClient.put(`${this.productUrl}/${data.id}`,data,{headers})
    .subscribe(data => {
      console.log(data);
    });
  }

  saveData(data){
    let id =  Math.floor((Math.random() * 100) + 1);
    console.log(id);
    data.id = id;
    let data1 = JSON.stringify(data);
    console.log(data1);
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.httpClient.post(`${this.productUrl}`,data1,{headers})
    .subscribe(data => {
      console.log(data);
    });
  }

  removeProductById(id:number){
    this.httpClient.delete(`${this.productUrl}/${id}`)
        .subscribe({
            next: data => {
                this.isProductDeleted.next(true);
                this.status = 'Delete successful';

            },
            error: error => {
              catchError(this.handleError)
            }
        });
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }
  ngOnDestroy(){
    this.ProductData.unsubscribe();
    this.isProductDeleted.unsubscribe();
    this.productsAddedToCart.unsubscribe();
  }
}
