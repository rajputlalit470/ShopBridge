import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IProduct } from '../shared/product.interface';
import { TableService } from '../table.service';
@Component({
  selector: 'app-modify-product',
  templateUrl: './modify-product.component.html',
  styleUrls: ['./modify-product.component.scss']
})
export class ModifyProductComponent implements OnInit {

  pageTitle = 'Modify Product';
  errorMessage = '';
  product: IProduct | undefined;
  constructor(private route: ActivatedRoute,
              private tableService: TableService) {
  }

  ngOnInit(): void {
    const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = +param;
      this.getProduct(id);
    }
  }
  
  getProduct(id: number): void {
    this.tableService.getProductById(id).subscribe({
      next: product => {
        this.product = product;
      },
      error: err => this.errorMessage = err
    });
  }
  getFormData(data){
      this.tableService.saveProductById(data); 
  }
}
