import { Component, Input, OnInit } from '@angular/core';
import { Router} from '@angular/router';
@Component({
  selector: 'app-button-component',
  templateUrl: './button-component.component.html',
  styleUrls: ['./button-component.component.scss']
})
export class ButtonComponentComponent implements OnInit {
  name:string;
  // @Input() buttonName: string;  
  @Input() 
  set buttonName(value: string) {
    this.name = value;
}
  constructor() { }

  ngOnInit(): void {
  }
  goToNextPage(){
  }
}
